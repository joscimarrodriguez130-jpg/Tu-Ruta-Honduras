export type Language = 'es' | 'en' | 'pt' | 'fr';

export type UserRole = 'user' | 'admin' | 'driver';

export interface Profile {
  id: string;
  full_name: string | null;
  phone: string | null;
  avatar_url: string | null;
  language: Language;
  location: string | null;
  role: UserRole;
  created_at: string;
  updated_at: string;
}

export type CompanyType = 'bus' | 'minibus' | 'taxi' | 'shuttle' | 'international';

export interface TransportCompany {
  id: string;
  name: string;
  slug: string;
  description: string | null;
  logo_url: string | null;
  phone: string | null;
  email: string | null;
  website: string | null;
  type: CompanyType;
  rating: number;
  total_reviews: number;
  is_active: boolean;
  created_at: string;
}

export interface ScheduleEntry {
  day: string;
  first: string;
  last: string;
}

export interface Route {
  id: string;
  company_id: string;
  name: string;
  origin_city: string;
  destination_city: string;
  origin_lat: number | null;
  origin_lng: number | null;
  destination_lat: number | null;
  destination_lng: number | null;
  waypoints: { lat: number; lng: number }[];
  distance_km: number | null;
  duration_minutes: number | null;
  price_hnl: number;
  price_usd: number | null;
  frequency: string | null;
  schedule: ScheduleEntry[];
  is_active: boolean;
  created_at: string;
  company?: TransportCompany;
}

export interface RouteStop {
  id: string;
  route_id: string;
  name: string;
  lat: number | null;
  lng: number | null;
  order_index: number;
  arrival_offset_minutes: number;
}

export type PaymentMethod = 'card' | 'cash' | 'transfer';
export type PaymentStatus = 'pending' | 'paid' | 'refunded' | 'cancelled';
export type BookingStatus = 'confirmed' | 'cancelled' | 'completed' | 'no_show';

export interface Booking {
  id: string;
  user_id: string;
  route_id: string | null;
  company_id: string | null;
  origin: string;
  destination: string;
  travel_date: string;
  travel_time: string | null;
  passengers: number;
  total_price_hnl: number | null;
  total_price_usd: number | null;
  payment_method: PaymentMethod | null;
  payment_status: PaymentStatus;
  booking_status: BookingStatus;
  notes: string | null;
  created_at: string;
  route?: Route;
  company?: TransportCompany;
}

export interface Review {
  id: string;
  user_id: string;
  company_id: string;
  booking_id: string | null;
  rating: number;
  comment: string | null;
  created_at: string;
  profile?: Profile;
}

export interface EmergencyContact {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  relationship: string | null;
  created_at: string;
}

export interface SearchParams {
  origin: string;
  destination: string;
  date: string;
  passengers: number;
}

export interface RouteResult {
  route: Route;
  company: TransportCompany;
  estimatedDuration: number;
  stops: string[];
}

export interface MapLocation {
  lat: number;
  lng: number;
  name?: string;
  address?: string;
}

export type AppView = 'home' | 'search' | 'results' | 'route-detail' | 'booking' | 'profile' | 'admin' | 'trips' | 'about';
